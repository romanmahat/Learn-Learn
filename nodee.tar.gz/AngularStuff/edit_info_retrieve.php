<?php
include('login_database_connection.php');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET,POST');

if(isset($_POST['username']))
{
		$username=$connect->quote($_POST['username']);

		$query='Select * from user where username="'.$username.'"';

		$statement=$connect->prepare($query);
		$statement->execute();
		$result=$statement->fetchAll();
		
		if($statement->rowCount()>0)
		{
			
			$res=array(
				'success'=>true,
				'username'=>substr($result[0][0],1,-1),
				'email'=>substr($result[0][2],1,-1),
				'profilepic'=>substr($result[0][3],1,-1),
				'type'=>substr($result[0][4],1,-1)
				);
			echo json_encode($res);

		}
		else
		{
			$res=array('success'=>false);
			echo json_encode($res);
		}
}



?>
