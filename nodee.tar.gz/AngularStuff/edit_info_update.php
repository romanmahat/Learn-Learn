<?php

include('login_database_connection.php');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET,POST');


if(isset($_POST['username']) && isset($_POST['email']))
	{

		$username=$connect->quote($_POST['username']);
		$email=$connect->quote($_POST['email']);
		$passwordQ="";
		$imageQ="";
	    
	   if(isset($_FILES['image']))
	    {
		
	//	    $target_dir = getcwd()."/uploads/";
		    $target_dir="/home/sasuke/nodetest/src/assets/uploads/";
		    $target_file = $target_dir . basename($_FILES["image"]["name"]);
		    $uploadOk = 1;
		    $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
		    
		    if (copy($_FILES["image"]["tmp_name"], $target_file)) 
		    {
			//if (copy("/home/sasuke/Documents/ChatLogin/madhu.jpg", $target_file)) {
			echo "The file ". basename( $_FILES["image"]["name"]). " has been uploaded.";
		    }
		    else
		    {
			echo "Sorry, there was an error uploading your file.";
		    }

		    $image="/assets/uploads/". basename($_FILES["image"]["name"]);
	   }
						

		if(isset($_POST['password']))
			$passwordQ=',password="'.md5($_POST['password']).'"';
		if(isset($_FILES['image']))
			$imageQ=',profilepic="'.$image.'"';		

$query='update user set username="'.$username.'",email="'.$email.'"'.$passwordQ.$imageQ.' where username="'.$connect->quote($_POST		['originalUsername']).'"';
		
echo $query;
		$statement=$connect->prepare($query);
		$statement->execute();
		$result=$statement->fetchAll();
		if(isset($result))
		{
			echo 'Success';
			//show an alert
			//header('location:login.php');
		}
		else
		{
			echo 'Failed';
		}
}


?>
