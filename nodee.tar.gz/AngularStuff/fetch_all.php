<?php
include('login_database_connection.php');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET,POST');

$query="SELECT p.id,p.user_id,p.message,u.profilepic from pool p,user u where u.username=p.user_id order by p.id";
	
$statement=$connect->prepare($query);
$statement->execute();
$result=$statement->fetchAll();

$message=array();

if($statement->rowCount()>0)
{
	foreach($result as $rows)
	{
		$message[]=$rows;
		//echo $rows['message'].'<br>';
	}
echo json_encode($message);
}
else
{
	echo "sorry no message available";
//	$message[]=array('message'=>"'Sorry no messages avalilable'");
}

?>
