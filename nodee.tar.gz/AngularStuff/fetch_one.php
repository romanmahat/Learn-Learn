<?php
include('login_database_connection.php');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET,POST');

$query="SELECT * from pool order by id desc";
	
$statement=$connect->prepare($query);
$statement->execute();
$result=$statement->fetchAll();

$message='';
if($statement->rowCount()>0)
{
	foreach($result as $rows)
	{
		$message=$rows[2];
		break;
	}
}
echo $message;
?>
