<?php
include('login_database_connection.php');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET,POST');


$currId=$_POST['current_id'];
//$currId=2;
$query="SELECT p.id,p.user_id,p.message,u.profilepic from pool p,user u where u.username=p.user_id and p.id>".$currId.' order by p.id';
//echo $query;
$statement=$connect->prepare($query);
$statement->execute();
$result=$statement->fetchAll();

$message=array();
$message[]=array('newmessages'=>$statement->rowCount());

if($statement->rowCount()>0)
{
	foreach($result as $rows)
	{
		$message[]=$rows;
		//echo $rows['message'].'<br>';
	}
}

echo json_encode($message);
?>
