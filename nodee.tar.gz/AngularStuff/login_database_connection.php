<?php
include('start_session.php');
$connect=new PDO("mysql:host=localhost;port=8889;dbname=bucky chat","root","");

//session_destroy();
?>
