<?php
include('login_database_connection.php');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET,POST');

if(isset($_POST['l_username']) && isset($_POST['l_password']))
{
		$username=$connect->quote($_POST['l_username']);

		$password=md5($_POST['l_password']);


		$query='Select profilepic,Type from user where username="'.$username.'" and password="'.$password.'"';

		$statement=$connect->prepare($query);
		$statement->execute();
		$result=$statement->fetchAll();
		
		if($statement->rowCount()>0)
		{
			$_SESSION['username']=$username;

			$res=array(
				'success'=>true,
				'username'=>$username,
				'profilepic'=>$result[0][0],
				'type'=>$result[0][1]
				);
			echo json_encode($res);

		}
		else
		{
			$res=array('success'=>false);
			echo json_encode($res);
		}
}



?>
