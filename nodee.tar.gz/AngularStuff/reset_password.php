<?php	
/*
include('login_database_connection.php');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET,POST');

if(isset($_POST['email']))
{
	$email=$connect->quote($_POST['email']);
	$query='select email from user where email="'.$email.'"';
	

	$statement=$connect->prepare($query);
	$statement->execute();
	$result=$statement->fetchAll();
	if($statement->rowCount()>0)
	{
*/
		$password=md5(rand(999, 99999));
		//$to=$_POST['email'];
		$to="dahalmanjil2016@gmail.com";		
		$subject="Your email recovery";
		
		$message="Please use this new password ".$password." to reset and change immediately after login";
		$headers="From: sasuke-Inspiron-3421";
		
		if(mail($to,$subject,$message,$headers))
		{
			echo json_encode('success');
		}
		else
		{
			echo json_encode('mailfail');
		}
	/*	
}
	else
	{
		echo json_encode('failure');
	}
	
}
*/
?>
