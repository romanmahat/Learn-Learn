<?php

function Everything()
{
include('login_database_connection.php');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET,POST');

$query='select * from AllVideos';
$statement=$connect->prepare($query);
$statement->execute();
$result=$statement->fetchAll();

if($statement->rowCount()>0)
{
	$allData=array();
	
	foreach($result as $row)
	{	
		
		$name=substr($row[1],1,-1);
		//$link=$row[2];
		$link=substr($row[2],1,-1);		

		$category=substr($row[3],1,-1);
		
		$onerow=array(
			'name'=>$name,
			'link'=>$link,
			'category'=>$category,
			'hashedcategory'=>md5($category.$name.$category)
		);	

			
		 $allData[]=$onerow;
				
	}
	echo json_encode($allData);
}
}

@Everything();

?>
