<?php
include('login_database_connection.php');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET,POST');


$emojs=[":)" => '&#x1F603;',":("=>'&#x1F61E;',":p"=>"&#x1F61C;",":D"=>"&#x1F606;",":*"=>"&#x1F618;"];

 if(isset($_POST['message']))
 {
 	$message=$_POST['message'];
	$message=trim($_POST['message']);
	
	foreach($emojs as $key=>$value)
	{
		$message=str_ireplace($key,$value,$message);
	}
	$userId=$_POST['userid'];
 	
	if(strlen($message)>0)
	{
		$message=$connect->quote($message);
		$userId=$connect->quote($userId);
		$query='INSERT into pool (user_id,message) VALUES("'.$userId.'","'.$message.'")';
		//$query='INSERT into pool (user_id,message) VALUES("WOW","DI")';

		$statement=$connect->prepare($query);
		$statement->execute();
		$result=$statement->fetchAll();
		if(isset($result))
		{
			echo 'Success';
		}
		else
		{
			echo 'Failed';
		}
	}
	else
		echo 'Please Enter Something';
}
else
	echo 'nt';

?>
