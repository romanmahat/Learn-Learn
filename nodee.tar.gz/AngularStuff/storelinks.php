<?php
include('login_database_connection.php');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET,POST');


if(isset($_POST['name']) && isset($_POST['link']) && isset($_POST['category']))
{
	$name=$connect->quote($_POST['name']);
	$link=$connect->quote($_POST['link']);
	$category=$connect->quote($_POST['category']);

	$query='Insert into AllVideos (name,link,category) values ("'.$name.'","'.$link.'","'.$category.'")';
	
	$statement=$connect->prepare($query);
	$statement->execute();
	$result=$statement->fetchAll();
	
	if(isset($result))
	{
		echo 'Success';
		//show an alert
		//header('location:login.php');
	}
	else
	{
		echo 'Failed';
	}

}
?>
