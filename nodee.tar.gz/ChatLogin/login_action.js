$(document).ready(function() {

    $('#login-form-link').click(function(e) {
		$("#login-form").delay(100).fadeIn(100);
 		$("#register-form").fadeOut(100);
		$('#register-form-link').removeClass('active');
		$(this).addClass('active');
		e.preventDefault();
	});
	$('#register-form-link').click(function(e) {
		$("#register-form").delay(100).fadeIn(100);
 		$("#login-form").fadeOut(100);
		$('#login-form-link').removeClass('active');
		$(this).addClass('active');
		e.preventDefault();
	});

	$('#confirm-password').keyup(function(){
		if($('#r_password').val()!=$('#confirm-password').val())
		{
			
			$('#confirm-password').css('border-color','#ef1616');
		}
		else
		{
			$('#confirm-password').css('border-color','#ddd');
		}
	});

	$('#register-submit').click(function(e)
	{
		if($('#r_password').val()!=$('#confirm-password').val())
		{
			e.preventDefault();
			alert("Password didn't match");
			$('#r_password').val("");
			$('#confirm-password').val("");
		}
	});

});



