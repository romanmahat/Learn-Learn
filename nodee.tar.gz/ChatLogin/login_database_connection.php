<?php
$connect=new PDO("mysql:host=localhost;port=8889;dbname=bucky chat","root","");
session_start();
//session_destroy();
?>
