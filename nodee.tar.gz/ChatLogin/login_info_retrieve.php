<?php
include('login_database_connection.php');
if(isset($_POST['login-submit']))
{
	if(isset($_POST['l_username']) && isset($_POST['l_password']))
	{
		$username=$connect->quote($_POST['l_username']);

		$password=md5($_POST['l_password']);


		$query='Select profilepic from user where username="'.$username.'" and password="'.$password.'"';

		$statement=$connect->prepare($query);
		$statement->execute();
		$result=$statement->fetchAll();
		
		if($statement->rowCount()>0)
		{
			//Render image
			$_SESSION['username']=$username;
	        header("location:loginview.php");
	        
		}
		else
		{
			echo 'enter correct credentials';
		}
	}
}


?>
