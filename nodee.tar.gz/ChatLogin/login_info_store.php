<?php
include('login_database_connection.php');
if(isset($_POST['register-submit']))
{
	if(isset($_POST['r_username']) && isset($_POST['r_password']) && isset($_POST['email']))
	{

		
		$target_dir = getcwd()."/uploads/";
	    $target_file = $target_dir . basename($_FILES["image"]["name"]);
	    $uploadOk = 1;
	    $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

	    if (copy($_FILES["image"]["tmp_name"], $target_file)) 
	    {
		//if (copy("/home/sasuke/Documents/ChatLogin/madhu.jpg", $target_file)) {
	        echo "The file ". basename( $_FILES["image"]["name"]). " has been uploaded.";
	    }
	    else
	    {
	        echo "Sorry, there was an error uploading your file.";
	    }

	    $image=basename( $_FILES["image"]["name"],".jpg");
        



		$username=$connect->quote($_POST['r_username']);
		$password=md5($_POST['r_password']);
		$email=$connect->quote($_POST['email']);

		$query='Insert into user (username,password,email,profilepic) values ("'.$username.'","'.$password.'","'.$email.'","'.$image.'")';
		//echo $query;
		$statement=$connect->prepare($query);
		$statement->execute();
		$result=$statement->fetchAll();
		if(isset($result))
		{
			echo 'Success';
			//show an alert
			header('location:login.php');
		}
		else
		{
			echo 'Failed';
		}
	}
}


?>