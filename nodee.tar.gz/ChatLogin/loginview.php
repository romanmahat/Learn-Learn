<?php
include('login_database_connection.php');
$query='Select profilepic from user where username="'.$_SESSION['username'].'"';
$statement=$connect->prepare($query);
$statement->execute();
$result=$statement->fetchAll();
$profpic=$result[0][0];

?>

<!DOCTYPE html>
<html>
<head>
	<title>Login View</title>
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  <!--	<link rel="stylesheet" href="css/bootstrap.min.css">
 	<script src="js/bootstrap.min.js"></script>
-->

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 	<style>

 		.navbar
		{
			border-radius: 0;
		}

 		.list-group-item:first-child
 		{
 			border-top-left-radius: 0px;
 			border-top-right-radius: 0px;
 		}
		.list-group-item:last-child
 		{
 			border-bottom-left-radius: 0px;
 			border-bottom-right-radius: 0px;
 		}
 		#list-home
 		{
 			background: url('a.jpg');
 			
 			height: 580px;
 			width: 830px;
 		}
 		#list-upload
 		{
 			background: url('b.jpg');
 			height: 580px;
 			width: 830px;
 		}
 		#list-message
 		{
 			background: url('c.jpg');
 			height: 580px;
 			width: 830px;
 		}
 		#list-notification
 		{
 			background: url('d.jpg');
 			height: 580px;
 			width: 830px;
 		}
 		#list-account-settings
 		{
 			background: url('e.jpg');
 			height: 580px;
 			width: 830px;
 		}
 		#list-logout
 		{
 			background: url('f.jpg');
 			height: 580px;
 			width: 830px;
 		}
 		#profile-picture
 		{
 			padding: 5px;
 			background-color: #ff6a00;
 			border: 1px solid grey;
 		}
 	</style>
</head>

<body>
	<div class="container-flex">
		<div class="row">
			<div class="col-lg-12" style="height: 10vh;">

				<nav class="navbar navbar-inverse">
					<div class="container-fluid">
					<!--header-->
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#topNavBar">
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
							<a class="navbar-brand" href="#">Manjil</a>
						</div>
						<!--Items-->
						<div class="collapse navbar-collapse" id="topNavBar">
							<ul class="nav navbar-nav">
								<li class="" >
									<a href="#">
										<span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;
										Home
									</a>
								</li>
							</ul>
							<ul class="nav navbar-nav navbar-right">
								<li class="" >
									<a href="#">
										<span class="glyphicon glyphicon-off" aria-hidden="true"></span>&nbsp;
										Logout
									</a>
								</li>
							</ul>
						</div>
					</div>
				</nav>
			</div>
		</div>

	<div class="row">
			<div class="col-lg-3" style="background-color:aqua;height: 88vh; padding-right: 0px;">

						<div id="profile-picture">
							<img src='<?php echo "uploads/".$result[0][0].".jpg" ?>' class="img-fluid" alt="no" style="width: 100%; height: 300px;">
						</div>
						<div  class="list-group nav-tabs">
							<a class="list-group-item list-group-item-action  active" id="list-home-list" data-toggle="tab" href="#list-home">Home</a>
							<a class="list-group-item list-group-item-action" id="list-upload-list" data-toggle="tab" href="#list-upload">Upload</a>
							<a class="list-group-item list-group-item-action" id="list-message-list" data-toggle="tab" href="#list-message">Messages<span class="badge">12</span></a>
							<a class="list-group-item list-group-item-action" id="list-notification-list" data-toggle="tab" href="#list-notification">Notification<span class="badge">12</span></a>
							<a class="list-group-item list-group-item-action" id="list-account-settings-list" data-toggle="tab" href="#list-account-settings">Account Settings</a>
							<a class="list-group-item list-group-item-action" id="list-logout-list" data-toggle="tab" href="#list-logout">Log Out</a>
						</div>
			</div>
			<div class="col-lg-9" style="background-color:green;height: 88vh;">
			  <div class="tab-content">
			      <div class="tab-pane fade in active" id="list-home" role="tabpanel"></div>
			      <div class="tab-pane fade" id="list-upload" role="tabpanel"></div>
			      <div class="tab-pane fade" id="list-message" role="tabpanel"></div>
			      <div class="tab-pane fade" id="list-notification" role="tabpanel"></div>
			      <div class="tab-pane fade" id="list-account-settings" role="tabpanel"></div>
			      <div class="tab-pane fade" id="list-logout" role="tabpanel"></div>
			    </div>
			</div>
		</div>
	</div>

	<script type="text/javascript">
   $(document).on('click', '.list-group-item-action', function() {
       $(".list-group-item-action").removeClass("active");
       $(this).addClass("active");
   });
</script>
</body>
</html>
