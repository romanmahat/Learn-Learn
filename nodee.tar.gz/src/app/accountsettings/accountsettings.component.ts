import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';

declare var jquery:any;
declare var $ :any;

@Component({
  selector: 'app-accountsettings',
  templateUrl: './accountsettings.component.html',
  styleUrls: ['./accountsettings.component.css']
})
export class AccountsettingsComponent implements OnInit {

  constructor(private http:Http) { }

  myData=[]

  ngOnInit() {
  	this.retriveInfo();

  	$('#user_reenter_password').keyup(function(){
		if($('#user_new_password').val()!=$('#user_reenter_password').val())
		{
			
			$('#user_reenter_password').css('border-color','#ef1616');
		}
		else
		{
			$('#user_reenter_password').css('border-color','#ddd');
		}
	});

	$('#edit_profile').click(function(e)
	{
		if($('#user_new_password')!='')
		{
			if($('#user_new_password').val()!=$('#user_reenter_password').val())
			{
				e.preventDefault();
				alert("Password didn't match");
				$('#user_new_password').val("");
				$('#user_reenter_password').val("");
			}
		}
	});

  }
  submitChanges(e)
  {
  	e.preventDefault();
  	var username=e.target.elements[0].value;
  	var email=e.target.elements[1].value;
  	var password=e.target.elements[3].value;
  	var image=e.target.elements[2].files[0];

  	let formData=new FormData();
  	formData.append('originalUsername',localStorage.getItem('username'));
  	formData.append('username',username);
  	formData.append('email',email);
  	if(password!='')
  		formData.append('password',password);

  	if(image)
  		formData.append('image',image);

  	this.http.post('http://localhost:8080/AngularStuff/edit_info_update.php',formData).
  	subscribe(
  		(data)=>
  		{
  			console.log(data);
  		},
  		(error)=>
  		{

  		});
  }
  retriveInfo()
  {
  	let formData=new FormData();
  	formData.append('username',localStorage.getItem('username'));
  	this.http.post('http://localhost:8080/AngularStuff/edit_info_retrieve.php',formData).
  	subscribe(
  		(data)=>
  		{
  			this.myData=data.json();
  		},
  		(error)=>
  		{

  		});
  }
}
