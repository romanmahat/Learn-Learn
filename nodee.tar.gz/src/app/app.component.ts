import { Component } from '@angular/core';

declare var jquery:any;
declare var $ :any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent
{

  profile_picture="";
  username="";
  type=""

  loggedIn=false;

  showhome=true;
  showupload=false;
  showmessage=false;
  shownotification=false;
  showaccountsettings=false;
  showlogout=false;
  showverify=false;

  ngOnInit()
  {
    //localStorage.removeItem('username');
    if(localStorage.getItem('username'))
    {
       this.loggedIn=true; 
       this.profile_picture=localStorage.getItem('profilepic');
       
       this.username=localStorage.getItem('username');
       this.type=localStorage.getItem('type');

    }
    $(document).on('click', '.list-group-item-action', function() {
       $(".list-group-item-action").removeClass("active");
       $(this).addClass("active");
   });
  }

  LoginSuccess(ev)
  {
    this.loggedIn=ev[0];
    this.profile_picture=localStorage.getItem('profilepic');
    this.username=localStorage.getItem('username');
    this.type=localStorage.getItem('type');
  }


  viewHome()
  {
      this.showhome=true;
      this.showupload=false;
      this.showmessage=false;
      this.shownotification=false;
      this.showaccountsettings=false;
      this.showlogout=false;
      this.showverify=false;
  }
  viewUpload()
  {	
      this.showhome=false;
      this.showupload=true;
      this.showmessage=false;
      this.shownotification=false;
      this.showaccountsettings=false;
      this.showlogout=false;
      this.showverify=false;
  }
  verifyUpload()
  {
      this.showverify=true;
      this.showhome=false;
      this.showupload=false;
      this.showmessage=false;
      this.shownotification=false;
      this.showaccountsettings=false;
      this.showlogout=false; 
  }
  viewMessage()
  {	
      this.showhome=false;
      this.showupload=false;
      this.showmessage=true;
      this.shownotification=false;
      this.showaccountsettings=false;
      this.showlogout=false;
      this.showverify=false;
  }
  viewNotification()
  {	
      this.showhome=false;
      this.showupload=false;
      this.showmessage=false;
      this.shownotification=true;
      this.showaccountsettings=false;
      this.showlogout=false;
      this.showverify=false;
  }
  viewAccountSettings()
  {
      this.showhome=false;
      this.showupload=false;
      this.showmessage=false;
      this.shownotification=false;
      this.showaccountsettings=true;
      this.showlogout=false;
      this.showverify=false;
  }
  viewLogout()
  {
      
      localStorage.removeItem('username');
      localStorage.removeItem('tpye');

      this.loggedIn=false;

      this.showhome=true;
      this.showupload=false;
      this.showmessage=false;
      this.shownotification=false;
      this.showaccountsettings=false;
      this.showlogout=false;
  }
}
