import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { LoginandsignupComponent } from './loginandsignup/loginandsignup.component';
import { LinkuploadComponent } from './linkupload/linkupload.component';
import { HomeComponent } from './home/home.component';
import { VerifyComponent } from './verify/verify.component';
import { AccountsettingsComponent } from './accountsettings/accountsettings.component';
import { ChatComponent } from './chat/chat.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginandsignupComponent,
    LinkuploadComponent,
    HomeComponent,
    VerifyComponent,
    AccountsettingsComponent,
    ChatComponent
  ],
  imports: [
    BrowserModule,
    HttpModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
