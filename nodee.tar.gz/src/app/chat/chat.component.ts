import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';


declare var jquery:any;
declare var $ :any;

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.css']
})



export class ChatComponent implements OnInit {

  action="";
  userId="a";
  cid=1000000000;

  constructor(private http:Http) 
  {

  }

  ngOnInit() 
  {
  	this.receiveMessage();
  	setInterval(()=>this.updateMessageotherside(),1000);
  }
  sendMessage()
  {
  	//setInterval(this.updateMessageotherside(),1000);

  	this.userId=localStorage.getItem('username');

  	this.action='send';
	var message=(<HTMLInputElement>document.getElementById("messageBox")).value;
	(<HTMLInputElement>document.getElementById("messageBox")).value="";
	
	let formData=new FormData();
	formData.append('message',message);
	formData.append('userid',this.userId);
	this.http.post('http://localhost:8080/AngularStuff/save_message.php',formData).
	subscribe((data)=>
	{
		console.log("Got some Data",data);
		this.updateMessage();
	}
	,(error)=>
	{
		console.log("Error:",error);
	});
  }

  updateMessage()
  {
  	this.action="receive";
  	this.http.get('http://localhost:8080/AngularStuff/fetch_one.php').
  	subscribe((data)=>
  	{
  		
  		var displayArea=<HTMLInputElement>document.getElementById("chatarea");
  		this.displayMessageUser(displayArea,data['_body']);
  	}
  	,(error)=>
  	{
  		console.log("Error:",error);
  	});
  }
  receiveMessage()
  {
  	this.action="receive";
  	this.http.get('http://localhost:8080/AngularStuff/fetch_all.php').
  	subscribe((data)=>
  	{
  		this.displayMessage(data.json());
  	}
  	,(error)=>{
  		console.log('Error:',error);
  	});
  }

  updateMessageotherside()
  {
  	this.action="receive";
  	
  	
  	var data=new FormData();
  	data.append('current_id',this.cid.toString());

  	this.http.post('http://localhost:8080/AngularStuff/fetch_other.php',data).
  	subscribe((data)=>
  	{
  		this.checkNewMessagesContinue(data.json());
  	},
  	(error)=>
  	{
  		console.log('Error:',error);
  	});
  	
  }


  getLengthInPixels(value)
  {
	var bdy=document.getElementsByTagName("body")[0];
	var s=document.createElement("span");
	s.innerHTML=value;
	s.style.visibility="hidden";
	bdy.appendChild(s);
	var len=s.offsetWidth;
	bdy.removeChild(s);
	return len;
  }

  displayMessageUser(displayArea,message)
  {
  	
	
	message=message.substr(1).slice(0,-1);

 	
 	var width=this.getLengthInPixels(message)+16; 	

 	//dcol.style.width=width+'px';
 	//dcol.style.width.max="164px";


	let p="<span _ngcontent-c2 class=chatmessage-user>"+message+"</span>";
	let dcol="<div _ngcontent-c2 class=messageContainer-user>"+p+"</div>";
 	let drow="<div _ngcontent-c2 class=mainmessageContainer-user></div>";
 	
 	let parsedRow = new DOMParser().parseFromString(drow, 'text/html');
 	let domrow = parsedRow.body.firstChild;

 	let parsedCol = new DOMParser().parseFromString(dcol, 'text/html');
 	let domcol = (<HTMLDivElement>parsedCol.body.firstChild);

 	domcol.style.width=width+'px';
 	domcol.style.maxWidth="164px";

 	domrow.appendChild(domcol);
 	displayArea.appendChild(domrow);

 	var objDiv = document.getElementById("chatarea");
	objDiv.scrollTop = objDiv.scrollHeight;	

  }
  displayMessageOther(displayArea,message,userid)
  {

	message=message.substr(1).slice(0,-1);
	
	var width=this.getLengthInPixels(message)+16;


 	let p="<span _ngcontent-c2 class=chatmessage-other>"+message+"</span>";
	let dcol="<div _ngcontent-c2 class=messageContainer-other>"+p+"</div>";
 	let drow="<div _ngcontent-c2 class=mainmessageContainer-other></div>";


 	//images
 	let imageareaString="<div _ngcontent-c2 class='userimage'></div>";
 	
 	var imagechild=document.createElement('img');
 	
 	if(userid=="roman")
 		imagechild.src="roman.jpg";
 	else if(userid=="madhu")
 		imagechild.src="madhu.jpg";
 	else if(userid=="manish")
 		imagechild.src="manish.png";
 	else
 		imagechild.src="manjil.jpg";

 	imagechild.className="img-circle";
 	imagechild.width=28;
 	imagechild.height=28;
 	

 	let imgarea=new DOMParser().parseFromString(imageareaString,'text/html');
 	let imagearea=imgarea.body.firstChild;

 	imagearea.appendChild(imagechild);

 	//

 	let parsedRow = new DOMParser().parseFromString(drow, 'text/html');
 	let domrow = parsedRow.body.firstChild;

 	let parsedCol = new DOMParser().parseFromString(dcol, 'text/html');
 	let domcol = (<HTMLDivElement>parsedCol.body.firstChild);

 	domcol.style.width=width+'px';
 	domcol.style.maxWidth="164px";

 	domrow.appendChild(imagearea);
 	domrow.appendChild(domcol);
 	displayArea.appendChild(domrow);

 	var objDiv = document.getElementById("chatarea");
	objDiv.scrollTop = objDiv.scrollHeight;	

 	

  }
  displayMessage(textResponse)
  {
	 
	  var user_id=localStorage.getItem('username');
	  var allMessages=textResponse;
	 
	  var displayArea=document.getElementById("chatarea");

	  for(var i=1;i<allMessages.length;i++)
	  {

	  	if(allMessages[i].user_id==user_id)
		 	this.displayMessageUser(displayArea,allMessages[i].message);
		 else
		 	this.displayMessageOther(displayArea,allMessages[i].message,allMessages[i].user_id);
	  }
	 this.cid=(allMessages[allMessages.length-1].id);
  }
  checkNewMessagesContinue(htmlResponse)
  {
	
	var allMessages=htmlResponse;
	
	//alert(allMessages[0].newmessages);
	if(allMessages[0].newmessages)
	{
		var displayArea=document.getElementById("chatarea");
		var i=0;
		for(i=1;i<allMessages.length;i++)
		{
			//alert(allMessages[i].user_id);
			if(allMessages[i].user_id!=localStorage.getItem('username'))
				this.displayMessageOther(displayArea,allMessages[i].message,allMessages[i].user_id);
		}
		
		this.cid=allMessages[allMessages.length-1].id;
		//alert("OK"+current_Id);
	}
	
   }
}
