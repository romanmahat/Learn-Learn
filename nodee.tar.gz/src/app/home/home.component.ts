import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';

declare var jquery:any;
declare var $ :any;


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})


export class HomeComponent implements OnInit {

  constructor(private http:Http) { }

  listOfLinks=[]
  currlink=[]
  categories=[]
  ids=[]
  catlinks={}
  loaded=false;
  clickedItem=false;
  
  
  ngOnInit() 
  {
  	this.GetLinks();
        $(document).on('click', '.list-group-item-success', function() {
       $(".list-group-item-success").removeClass("active");
       $(this).addClass("active");
   });

    
    
  }



  selected(a,b)
  {
    this.clickedItem=true;
    this.currlink=[a,b];
  }


  GetLinks()
  {
    var d=<HTMLDivElement>document.getElementById('ournavigationbar');
    d.hidden=true;

	 this.http.get('http://localhost:8080/AngularStuff/playlistRetriever.php')
	 .subscribe((data)=>
	 {
	 	console.log("Got some data",data);
    if(data['_body']=='')
      return;

	 	this.listOfLinks=data.json();
    if(this.listOfLinks.length==0)
      return;
    for(var i=0;i<this.listOfLinks.length;i++)
        {
          this.categories.push(this.listOfLinks[i]['category']);
          this.ids.push(this.listOfLinks[i]['hashedcategory']);
          if(!this.catlinks[this.listOfLinks[i]['category']])
              this.catlinks[this.listOfLinks[i]['category']]=[]
           
          var tempname=this.listOfLinks[i]['name'];
          var templink=this.listOfLinks[i]['link'];
          var tempnamelinkpair=[tempname,templink];

          this.catlinks[this.listOfLinks[i]['category']].push(tempnamelinkpair);
        }
    this.categories=Array.from(new Set(this.categories));
    this.ids=Array.from(new Set(this.ids));
    console.log(this.categories);


   
    this.currlink=this.catlinks[this.categories[0]][0];


    d.hidden=false;
	 	this.loaded=true;

	 },(error)=>
	 {
	 	console.log("Error",error);
	 })
}
}
