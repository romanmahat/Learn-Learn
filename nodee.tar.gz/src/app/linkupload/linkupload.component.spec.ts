import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LinkuploadComponent } from './linkupload.component';

describe('LinkuploadComponent', () => {
  let component: LinkuploadComponent;
  let fixture: ComponentFixture<LinkuploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LinkuploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinkuploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
