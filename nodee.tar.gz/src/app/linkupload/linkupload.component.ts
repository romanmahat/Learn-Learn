import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';

declare var jquery:any;
declare var $ :any;


@Component({
  selector: 'app-linkupload',
  templateUrl: './linkupload.component.html',
  styleUrls: ['./linkupload.component.css']
})
export class LinkuploadComponent implements OnInit {

  wallsrc="/assets/uploads/ytube.jpg";

  constructor(private http: Http) { }
  
  ngOnInit() 
  {
     
  }

  uploadLink(e)
  {
  	e.preventDefault();
  	var name=e.target.elements[0].value;
  	var link=e.target.elements[1].value;
  	var category=e.target.elements[2].value;

  	let formData=new FormData();
  	formData.append("name",name);
  	formData.append("link",link);
  	formData.append("category",category);

  	this.http.post('http://localhost:8080/AngularStuff/playlistGenerator.php',formData)
  	.subscribe((data)=>{
  		console.log("Got some data",data);
  	 	e.target.reset();
  	},(error)=>{
  		console.log("Error",error);
  	});

  }
  selectNew()
  {
    var t=(<HTMLSelectElement>document.getElementById('options'));

    if(!t.selectedOptions[0].innerHTML.includes('button'))
      return;
    document.getElementById('wow').click();
  }
  newOption()
  {
    
    var op=(<HTMLSelectElement>document.getElementById('options'));

    var value=(<HTMLInputElement>document.getElementById('newValue')).value;
    (<HTMLInputElement>document.getElementById('newValue')).value='';
    
    var option = document.createElement("option");
    option.text = value;

    op.add(option); 
    op.selectedIndex=op.length-1;

    var temp=op[op.length-2];
    op[op.length-2]=op[op.length-1]
    op.add(temp);
  }
  dismisNew()
  {
    var op=(<HTMLSelectElement>document.getElementById('options'));
    op.selectedIndex=0;
  }

        
        


}
