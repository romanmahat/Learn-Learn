import { Component, OnInit , Output, EventEmitter} from '@angular/core';
import { Http } from '@angular/http';

declare var jquery:any;
declare var $ :any;

@Component({
  selector: 'app-loginandsignup',
  templateUrl: './loginandsignup.component.html',
  styleUrls: ['./loginandsignup.component.css']
})

export class LoginandsignupComponent implements OnInit {


  @Output() onsuccessfullogin = new EventEmitter();

  constructor(private http: Http) { }

  ngOnInit() 
  {

  	 $('#login-form-link').click(function(e) {
		$("#login-form").delay(100).fadeIn(100);
 		$("#register-form").fadeOut(100);
		$('#register-form-link').removeClass('active');
		$(this).addClass('active');
		e.preventDefault();
	});
	$('#register-form-link').click(function(e) {
		$("#register-form").delay(100).fadeIn(100);
 		$("#login-form").fadeOut(100);
		$('#login-form-link').removeClass('active');
		$(this).addClass('active');

		e.preventDefault();
	});

	$('#confirm-password').keyup(function(){
		if($('#r_password').val()!=$('#confirm-password').val())
		{
			
			$('#confirm-password').css('border-color','#ef1616');
		}
		else
		{
			$('#confirm-password').css('border-color','#ddd');
		}
	});

	$('#register-submit').click(function(e)
	{
		if($('#r_password').val()!=$('#confirm-password').val())
		{
			e.preventDefault();
			alert("Password didn't match");
			$('#r_password').val("");
			$('#confirm-password').val("");
		}
	});
  }


  loginUser(e)
  {	

  	e.preventDefault();
  	var username=e.target.elements[0].value;
  	var password=e.target.elements[1].value;
  	let formData=new FormData();
  	formData.append('l_username',username);
  	formData.append('l_password',password);

	 this.http.post('http://localhost:8080/AngularStuff/login_info_retrieve.php',formData)
	 .subscribe((data)=>
	 {
	 	console.log("Got some data",data);
	 	console.log(data);
	 	var condition=data.json();
	 	 if(condition['success']==true)
	 	 {
	 	 	console.log(condition['type']);
	 	 	console.log("Logged in");
	 	 	e.target.reset();

	 	 	var tempusername=condition['username'];

	 	 	
	 	 	localStorage.setItem('username',tempusername.substr(1).slice(0,-1));
	 	 	localStorage.setItem('profilepic',condition['profilepic']);
	 	 	localStorage.setItem('type',condition['type']);

	 	 	var successdata=[true];
	 	 	this.onsuccessfullogin.emit(successdata);



	 	 }
	 	 else
	 	 {
	 	 	console.log("failed");
	 	 	e.target.reset();
	 	 	alert("Please Enter Valid Credentials");
	 	 }

	 },(error)=>
	 {
	 	console.log("Error",error);
	 })
  }
  registerUser(e)
  {
  	e.preventDefault();
  	var username=e.target.elements[0].value;
  	var email=e.target.elements[1].value;
  	var password=e.target.elements[2].value;
  	var profilepic=e.target.elements[4].files[0];

  	 let formData=new FormData();
  	 formData.append('r_username',username);
  	 formData.append('email',email);
  	 formData.append('r_password',password);
  	 formData.append('image',profilepic);
  		
  	 this.http.post('http://localhost:8080/AngularStuff/login_info_store.php',formData)
  	 .subscribe((data)=>
  	 {
  	 	console.log("Got some data",data);
  	 	e.target.reset();
  	 	$('#login-form-link').trigger("click");

  	 },(error)=>
  	 {
  	 	console.log("Error",error);
  	 })

  }

}
