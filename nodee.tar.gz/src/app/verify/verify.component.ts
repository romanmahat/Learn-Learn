import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';

declare var jquery:any;
declare var $ :any;


@Component({
  selector: 'app-verify',
  templateUrl: './verify.component.html',
  styleUrls: ['./verify.component.css']
})
export class VerifyComponent implements OnInit {

  listOfLinks=[]
  selectedLinks=[]
  deleteLinks=[]

  constructor(private http:Http) {}

  ngOnInit()
  {
  	this.GetLinks();
  }

  GetLinks()
  {
	 this.http.get('http://localhost:8080/AngularStuff/retrieveAllTempUploads.php')
	 .subscribe((data)=>
	 {
	 	console.log("Got some data",data);
	 	this.listOfLinks=data.json();
	 	console.log(this.listOfLinks);

	 },(error)=>
	 {
	 	console.log("Error",error);
	 })
  }
  viewLink(l)
  {
  	 var link = document.createElement('a');
	 link.target = '_blank';
	 link.href = l;
	 link.setAttribute('visibility', 'hidden');
	 link.click();
  }
  removeFromDelete(d)
  {
  	this.deleteLinks = this.deleteLinks.filter(item => item['hashedcategory'] !== d['hashedcategory']);
  }
  removeFromSelect(d)
  {
  		this.selectedLinks = this.selectedLinks.filter(item => item['hashedcategory'] !== d['hashedcategory']);
  }
  selectLink(s)
  {
  
  	var eid=s['hashedcategory'];
  	$('.'+eid).eq(0).addClass('disabled');
	$('.'+eid).eq(1).removeClass('disabled');
	$('.'+eid).eq(0).attr('disabled',true);
	$('.'+eid).eq(1).attr('disabled',false);

  	this.selectedLinks.push(s);
  	this.removeFromDelete(s);

  }
  deleteLink(s)
  {
  	var eid=s['hashedcategory'];
  	$('.'+eid).eq(1).addClass('disabled');
  	$('.'+eid).eq(0).removeClass('disabled');
  	$('.'+eid).eq(1).attr('disabled',true);
  	$('.'+eid).eq(0).attr('disabled',false);
  	
  	this.deleteLinks.push(s);
  	this.removeFromSelect(s);

  }
  apply()
  {
  	 this.selectedLinks=Array.from(new Set(this.selectedLinks));
  	 this.deleteLinks=Array.from(new Set(this.deleteLinks));

  	 //send to main database

  }

  removeFromDatabase(l)
  {
  	var c=confirm('Are you sure wanna remove?');
  	if(!c)
  		return;

  	$('#'+l['hashedcategory']).parent().parent().remove();

  	let formData=new FormData();
  	formData.append('name',l['name']);
  	formData.append('link',l['link']);
  	formData.append('category',l['category']);
  	this.remove(formData);
  	

  }
  remove(formData)
  {
  	this.http.post('http://localhost:8080/AngularStuff/removeFromTemp.php',formData)
  	.subscribe(
  		(data)=>
  		{
  			console.log(data);
  		},
  		(error)=>
  		{
  			console.log("Error",error);
  		});
  }
  addToNewDatabase(l)
  {
  	var c=confirm('Are you sure wanna add?');
  	if(!c)
  		return;
  	$('#'+l['hashedcategory']).parent().parent().remove();
  	
  	let formData=new FormData();
  	formData.append('name',l['name']);
  	formData.append('link',l['link']);
  	formData.append('category',l['category']);
  	this.remove(formData);

  	this.http.post('http://localhost:8080/AngularStuff/mainVideoDatabaseSave.php',formData)
  	.subscribe((data)=>{
  		console.log("Got some data",data);
  	},(error)=>{
  		console.log("Error",error);
  	});
  	

  }
}
